$(document).ready(function(){
    $.ajax({
      url: "http://localhost/ex11/data.php",
      method: "GET",
      success: function(data) {
        console.log(data);
        var book_name = [];
        var pages = [];
  
        for(var i in data) {
          book_name.push( data[i].book_name);
          pages.push(data[i].pages);
        }
  
        var chartdata = {
          labels: book_name,
          datasets : [
            {
              label: 'book_name pages',
              backgroundColor: 'rgba(200, 200, 200, 0.75)',
              borderColor: 'rgba(200, 200, 200, 0.75)',
              hoverBackgroundColor: 'rgba(200, 200, 200, 1)',
              hoverBorderColor: 'rgba(200, 200, 200, 1)',
              data: pages
            }
          ]
        };
  
        var ctx = $("#mycanvas");
  
        var barGraph = new Chart(ctx, {
          type: 'pie',
          data: chartdata
        });
      },
      error: function(data) {
        console.log(data);
      }
    });
  });